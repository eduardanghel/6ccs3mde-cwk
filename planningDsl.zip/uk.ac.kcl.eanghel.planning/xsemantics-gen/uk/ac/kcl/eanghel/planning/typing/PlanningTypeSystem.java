package uk.ac.kcl.eanghel.planning.typing;

import it.xsemantics.runtime.XsemanticsRuntimeSystem;

@SuppressWarnings("all")
public class PlanningTypeSystem extends XsemanticsRuntimeSystem {
  public PlanningTypeSystem() {
    init();
  }
  
  public void init() {
    
  }
}
